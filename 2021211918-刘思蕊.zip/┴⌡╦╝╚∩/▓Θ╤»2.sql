SELECT city
FROM Cities
WHERE country = 'Ireland';