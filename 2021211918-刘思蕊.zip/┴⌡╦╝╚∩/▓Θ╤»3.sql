SELECT Airports.name,Cities.city,Cities.country
FROM Cities
    INNER JOIN Airports ON Cities.id = Airports.city_id