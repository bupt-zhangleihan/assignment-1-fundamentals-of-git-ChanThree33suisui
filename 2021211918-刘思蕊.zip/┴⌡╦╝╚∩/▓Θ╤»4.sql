SELECT Airports.name,Cities.city
FROM Cities
    INNER JOIN Airports ON Cities.id = Airports.city_id
WHERE Cities.city = 'London'