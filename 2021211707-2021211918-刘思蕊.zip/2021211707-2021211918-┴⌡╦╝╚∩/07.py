import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
plt.rcParams["figure.figsize"] = (10,3)
base_url = "https://raw.githubusercontent.com/CSSEGISandData/COVID-19/master/csse_covid_19_data/csse_covid_19_time_series/"
infected_dataset_url = base_url + "time_series_covid19_confirmed_global.csv"
recovered_dataset_url = base_url + "time_series_covid19_recovered_global.csv"
deaths_dataset_url = base_url + "time_series_covid19_deaths_global.csv"
countries_dataset_url = base_url + "../UID_ISO_FIPS_LookUp_Table.csv"
infected = pd.read_csv(infected_dataset_url)
print(infected.head())
infected_df = pd.read_csv(infected_dataset_url)
recovered_df = pd.read_csv(recovered_dataset_url)
deaths_df = pd.read_csv(deaths_dataset_url)
countries_df = pd.read_csv(countries_dataset_url)


countries_list = ["China", "US", "India", "Brazil", "Russia"]  # 选择五个国家进行比较

plt.figure(figsize=(12, 6))

for country in countries_list:
    infected_country = infected_df[infected_df["Country/Region"] == country].iloc[:, 4:].sum()
    recovered_country = recovered_df[recovered_df["Country/Region"] == country].iloc[:, 4:].sum()
    deaths_country = deaths_df[deaths_df["Country/Region"] == country].iloc[:, 4:].sum()

    rt = infected_country.diff() / recovered_country.shift()  # 假设 recovered 是治愈人数，可以根据实际情况调整

    plt.plot(rt, label=country)

plt.title('Rt Comparison for Selected Countries')
plt.xlabel('Date')
plt.ylabel('Rt Value')
plt.legend()
plt.grid(True)
plt.show()

plt.figure(figsize=(12, 8))

for country in countries_list:
    infected_country = infected_df[infected_df["Country/Region"] == country].iloc[:, 4:].sum()
    recovered_country = recovered_df[recovered_df["Country/Region"] == country].iloc[:, 4:].sum()
    deaths_country = deaths_df[deaths_df["Country/Region"] == country].iloc[:, 4:].sum()


    plt.plot(infected_country, label=f'{country} - Infected')
    plt.plot(recovered_country, label=f'{country} - Recovered')
    plt.plot(deaths_country, label=f'{country} - Deaths')

plt.title('Infection, Recovery, and Death Comparison for Selected Countries')
plt.xlabel('Date')
plt.ylabel('Number of Cases')
plt.legend()
plt.grid(True)
plt.show()


plt.figure(figsize=(12, 6))

for country in countries_list:
    infected_country = infected_df[infected_df["Country/Region"] == country].iloc[:, 4:].sum()
    deaths_country = deaths_df[deaths_df["Country/Region"] == country].iloc[:, 4:].sum()

    
    fatality_rate = deaths_country / infected_country * 100

   
    plt.plot(fatality_rate, label=country)

plt.title('Fatality Rate Comparison for Selected Countries')
plt.xlabel('Date')
plt.ylabel('Fatality Rate (%)')
plt.legend()
plt.grid(True)
plt.show()